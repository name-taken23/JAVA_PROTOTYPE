import org.eclipse.paho.mqttv5.client.*;
import org.eclipse.paho.mqttv5.client.persist.MemoryPersistence;
import org.eclipse.paho.mqttv5.common.MqttException;
import org.eclipse.paho.mqttv5.common.MqttMessage;

public class Clienttwo {
    static String topic = "test";
    static String content = "Hello I am Client Two";
    static String username = "client2";
    static String password = "two";
    static int qos = 2;
    static String broker = "tcp://localhost:1883";
    static String clientId = "ClientTwo";
    static MemoryPersistence persistence = new MemoryPersistence();
    static MqttAsyncClient client;
    public static void main(String[] args) {

        try {
            client = new MqttAsyncClient(broker, clientId);
            MqttConnectionOptions connectionOptions = new MqttConnectionOptions();
            connectionOptions.setUserName(username);
            connectionOptions.setPassword(password.getBytes());
            System.out.println("Connecting to broker: "+broker);
            client.connect(connectionOptions,null, new MqttActionListener() {
                @Override
                public void onSuccess(IMqttToken iMqttToken) {
                    try {
                        System.out.println("Connected");
                        System.out.println("Publishing message: "+content);
                        MqttMessage message = new MqttMessage(content.getBytes());
                        message.setQos(qos);
                        client.publish(topic, message);
                        System.out.println("Message published");
                    } catch (MqttException e) {
                        throw new RuntimeException(e);
                    }
                }

                @Override
                public void onFailure(IMqttToken iMqttToken, Throwable throwable) {

                }
            });


        } catch (MqttException e) {
            throw new RuntimeException(e);
        }


    }
}
