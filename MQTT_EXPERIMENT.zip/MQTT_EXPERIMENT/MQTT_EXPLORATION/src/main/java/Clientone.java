import org.eclipse.paho.mqttv5.client.*;
import org.eclipse.paho.mqttv5.client.persist.MemoryPersistence;
import org.eclipse.paho.mqttv5.common.MqttException;
import org.eclipse.paho.mqttv5.common.MqttMessage;
import org.eclipse.paho.mqttv5.common.packet.MqttProperties;

public class Clientone {

    static String topic = "test";

    static String username = "client1";
    static String password = "one";
    static int qos = 2;
    static String broker = "tcp://localhost:1883";
    static String clientId = "ClientOne";
    static MemoryPersistence persistence = new MemoryPersistence();
    static MqttAsyncClient client;
    public static void main(String[] args) {
        try {
            client = new MqttAsyncClient(broker, clientId);
            MqttConnectionOptions connectionOptions = new MqttConnectionOptions();
            connectionOptions.setUserName(username);
            connectionOptions.setPassword(password.getBytes());
            System.out.println("Connecting to broker: "+broker);
            client.connect(connectionOptions,null, new MqttActionListener() {
                @Override
                public void onSuccess(IMqttToken iMqttToken) {
                    try {
                        client.subscribe(topic, 2);
                    } catch (MqttException e) {
                        throw new RuntimeException(e);
                    }
                }

                @Override
                public void onFailure(IMqttToken iMqttToken, Throwable throwable) {
                    try {
                        System.out.println(iMqttToken.getMessage());
                    } catch (MqttException e) {
                        throw new RuntimeException(e);
                    }
                }
            });

        client.setCallback(new MqttCallback() {
            @Override
            public void disconnected(MqttDisconnectResponse mqttDisconnectResponse) {

            }

            @Override
            public void mqttErrorOccurred(MqttException e) {

            }

            @Override
            public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
                System.out.println(mqttMessage.toString());
            }

            @Override
            public void deliveryComplete(IMqttToken iMqttToken) {

            }

            @Override
            public void connectComplete(boolean b, String s) {

            }

            @Override
            public void authPacketArrived(int i, MqttProperties mqttProperties) {

            }
        });
        } catch (MqttException e) {
            throw new RuntimeException(e);
        }
    }
}
