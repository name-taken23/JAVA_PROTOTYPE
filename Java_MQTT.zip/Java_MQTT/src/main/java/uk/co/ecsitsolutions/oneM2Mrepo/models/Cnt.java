package uk.co.ecsitsolutions.oneM2Mrepo.models;

public class Cnt {

    public String[] acpi;

    public String rn;
    public int mni;

    public void setConData(String[] acpi, String rn, int mni){
        this.acpi = acpi;
        this.rn = rn;
        this.mni = mni;
    }
}
