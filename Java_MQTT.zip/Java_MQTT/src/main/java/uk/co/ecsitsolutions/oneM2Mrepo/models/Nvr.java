package uk.co.ecsitsolutions.oneM2Mrepo.models;

public class Nvr {
    int rsc;
    String rqi;
    String rvi;

    public void setNvrData(int rsc, String rqi, String rvi){
        this.rsc = rsc;
        this.rqi = rqi;
        this.rvi = rvi;
    }
}
