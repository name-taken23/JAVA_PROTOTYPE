package uk.co.ecsitsolutions.oneM2Mrepo.models;

public class Acp {

    public String rn;
    public Acr pv;

    public Acr pvs;

    public void setAcpData(String rn, Acr pv, Acr pvs){
        this.rn = rn;
        this.pv = pv;
        this.pvs = pvs;
    }
}
