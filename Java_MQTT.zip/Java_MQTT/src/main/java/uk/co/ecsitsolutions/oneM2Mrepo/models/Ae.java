package uk.co.ecsitsolutions.oneM2Mrepo.models;

import java.util.ArrayList;

public class Ae {
    public String rn;
    public String api;
    public boolean rr;
    public ArrayList<String> srv;

    public void setAeFields(String rn, String api, boolean rr, ArrayList<String> srv){
        this.rn = rn;
        this.api = api;
        this.rr = rr;
        this.srv = srv;
    }

    public void setRn(String rn) {
        this.rn = rn;
    }

    public void setApi(String api) {
        this.api = api;
    }

    public void setRr(boolean rr) {
        this.rr = rr;
    }

    public void setSrv(ArrayList<String> srv) {
        this.srv = srv;
    }
}
