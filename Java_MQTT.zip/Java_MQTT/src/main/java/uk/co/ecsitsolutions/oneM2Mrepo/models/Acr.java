package uk.co.ecsitsolutions.oneM2Mrepo.models;

public class Acr {
    public Acor[] acr;

    public void setAcr(Acor[] acr){
        this.acr = acr;
    }
}
