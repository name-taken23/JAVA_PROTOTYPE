package uk.co.ecsitsolutions.oneM2Mrepo;

public class OneM2MmqttWrapper {

    public int op;
    public String to;
    public String fr;
    public String rqi;
    public int ty;
    public String rvi;
    public Object pc;
}
