package uk.co.ecsitsolutions.oneM2Mrepo.models;

public class Sub {

    public NotificationEventType enc;
    public String[] nu;
    public String rn;

    public void setSubResourceData(NotificationEventType enc, String[] nu, String rn){
        this.enc = enc;
        this.nu = nu;
        this.rn = rn;
    }

    public class NotificationEventType {
        public int[] net;

        public void setNet(int[] netArray) {
            this.net = netArray;
        }
    }
}
