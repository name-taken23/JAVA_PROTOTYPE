package uk.co.ecsitsolutions.oneM2Mrepo.models;

public class Acor {

    public String[] acor;
    public int acop;

    public void setAcrData(String[] acor, int acop){
        this.acor = acor;
        this.acop = acop;
    }
}
