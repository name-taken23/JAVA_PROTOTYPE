package uk.co.ecsitsolutions.oneM2Mrepo.models;

public class Cin {
    public Object con;

    public void setCinData(Object cin){
        this.con = cin;
    }
}
