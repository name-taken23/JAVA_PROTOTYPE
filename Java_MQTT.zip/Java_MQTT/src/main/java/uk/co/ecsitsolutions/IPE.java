package uk.co.ecsitsolutions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.eclipse.paho.mqttv5.client.IMqttToken;
import org.eclipse.paho.mqttv5.client.MqttCallback;
import org.eclipse.paho.mqttv5.client.MqttClient;
import org.eclipse.paho.mqttv5.client.MqttDisconnectResponse;
import org.eclipse.paho.mqttv5.common.MqttException;
import org.eclipse.paho.mqttv5.common.MqttMessage;
import org.eclipse.paho.mqttv5.common.packet.MqttProperties;
import uk.co.ecsitsolutions.oneM2Mrepo.OneM2MWrapper;
import uk.co.ecsitsolutions.oneM2Mrepo.OneM2MmqttWrapper;
import uk.co.ecsitsolutions.oneM2Mrepo.models.*;

import java.util.ArrayList;
import java.util.Map;

public class IPE {

    static String cavTopic = "CAV/latlng";
    static String cseRequestTopic = "/oneM2M/req/CIPE/id-in/json";
    static String serverURI = "tcp://127.0.0.1:1883";
    static String clientID = "IPE";

    static MqttClient ipeClient;


    public static void main(String[] args) throws MqttException {
        ipeClient = new MqttClient(serverURI, clientID);
        ipeClient.connect();
        ipeClient.subscribe(cavTopic, 1);
        ObjectMapper mapper = new ObjectMapper();
        if (ipeClient.isConnected()) {
            Map<String, Object> aeObject, acpObject, latlntContainer;
            OneM2MmqttWrapper mqttWrapper = new OneM2MmqttWrapper();
            Cnt cnt = new Cnt();
            ArrayList<String> srv = new ArrayList<>();
            srv.add("3");

            String[] acorResources = {"CIPE", "CV2X", "CAdmin"};
            Ae ae = new Ae();
            Acp acp = new Acp();
            Acor acor = new Acor();
            Acr acr = new Acr();
            Acor[] parsedAcor;
            parsedAcor = new Acor[]{acor};
            acor.setAcrData(acorResources, 63);
            acr.setAcr(parsedAcor);
            acp.setAcpData("acp1", acr, acr);

            ae.setAeFields("CAV", "NCAV", true, srv);

            String[] acpArray = new String[]{"cse-in/acp1"};
            cnt.setConData(acpArray, "latlng", 100);

            latlntContainer = OneM2MWrapper.createOneM2MWrapper("m2m:cnt", cnt);
            aeObject = OneM2MWrapper.createOneM2MWrapper("m2m:ae", ae);
            acpObject = OneM2MWrapper.createOneM2MWrapper("m2m:acp", acp);

            String content;
            MqttMessage payload;
            try {
                mqttWrapper.op = 1;
                mqttWrapper.to = "/id-in/cse-in";
                mqttWrapper.fr = "CIPE";
                mqttWrapper.rqi = "1234";
                mqttWrapper.rvi = "3";
                mqttWrapper.pc = aeObject;
                mqttWrapper.ty = 2;
                content = mapper.writeValueAsString(mqttWrapper);
                System.out.println(content);
                payload = new MqttMessage(content.getBytes());
                ipeClient.publish(cseRequestTopic, payload);

                mqttWrapper.pc = acpObject;
                mqttWrapper.ty = 1;
                content = mapper.writeValueAsString(mqttWrapper);
                System.out.println(content);
                payload = new MqttMessage(content.getBytes());
                ipeClient.publish(cseRequestTopic, payload);

                Thread.sleep(1000);
                mqttWrapper.pc = latlntContainer;
                mqttWrapper.ty = 3;
                mqttWrapper.to = "/id-in/cse-in/CAV";
                content = mapper.writeValueAsString(mqttWrapper);
                System.out.println(content);
                payload = new MqttMessage(content.getBytes());
                ipeClient.publish(cseRequestTopic, payload);

            } catch (JsonProcessingException | MqttException | InterruptedException e) {
                throw new RuntimeException(e);
            }


        }
        ipeClient.setCallback(new MqttCallback() {
            @Override
            public void disconnected(MqttDisconnectResponse mqttDisconnectResponse) {

            }

            @Override
            public void mqttErrorOccurred(MqttException e) {

            }

            @Override
            public void messageArrived(String s, MqttMessage mqttMessage) throws Exception {
                OneM2MmqttWrapper mqttWrapper = new OneM2MmqttWrapper();
                MqttMessage payload;
                Map<String, Object> cinContainer;
                if(s.equals("CAV/latlng"));
                System.out.println("topic: " + s);
                System.out.println("qos: " + mqttMessage.getQos());
                System.out.println("content: " + new String(mqttMessage.getPayload()));
                Map<String, Object> contentInstanceObject;
                Cin cin = new Cin();
                JsonNode node = mapper.readTree(mqttMessage.getPayload());
                cin.setCinData(node.get("latitude") + "," + node.get("longitude"));
                cinContainer = OneM2MWrapper.createOneM2MWrapper("m2m:cin", cin);
                mqttWrapper.op = 1;
                mqttWrapper.to = "/id-in/cse-in/CAV/latlng";
                mqttWrapper.fr = "CIPE";
                mqttWrapper.rqi = "1234";
                mqttWrapper.rvi = "3";
                mqttWrapper.pc = cinContainer;
                mqttWrapper.ty = 4;
                String content = mapper.writeValueAsString(mqttWrapper);
                System.out.println(content);
                payload = new MqttMessage(content.getBytes());
                ipeClient.publish(cseRequestTopic, payload);
            }

            @Override
            public void deliveryComplete(IMqttToken iMqttToken) {

            }

            @Override
            public void connectComplete(boolean b, String s) {

            }

            @Override
            public void authPacketArrived(int i, MqttProperties mqttProperties) {

            }
        });
    }


}

